
import React, { useState, useRef, KeyboardEvent } from "react";
import { Send, FileUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useChat } from "@/contexts/ChatContext";
import FileUpload from "./FileUpload";
import { toast } from "@/hooks/use-toast";

const ChatInput: React.FC = () => {
  const [message, setMessage] = useState("");
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { sendMessage, isLoading } = useChat();

  const handleSubmit = async () => {
    if ((message.trim() || selectedFile) && !isLoading) {
      try {
        // Update chat UI with message and file
        await sendMessage(message, selectedFile);
        
        // Clear form
        setMessage("");
        setSelectedFile(null);
        
        // Reset textarea height after sending
        if (textareaRef.current) {
          textareaRef.current.style.height = "auto";
        }
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Message failed",
          description: "Failed to send your message. Please try again.",
        });
        console.error("Error handling submission:", error);
      }
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    
    // Auto-resize the textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${Math.min(
        textareaRef.current.scrollHeight,
        200 // Max height in pixels
      )}px`;
    }
  };

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    setShowFileUpload(false);
    
    toast({
      title: "File attached",
      description: "The AI will analyze this file to learn from it.",
    });
  };

  const handleClearFile = () => {
    setSelectedFile(null);
  };

  return (
    <div className="p-4 border-t border-border bg-background/95 backdrop-blur-sm">
      <div className="relative max-w-4xl mx-auto">
        {showFileUpload ? (
          <div className="mb-4">
            <FileUpload 
              onFileSelect={handleFileSelect} 
              selectedFile={selectedFile}
              onClearFile={handleClearFile}
            />
            <div className="mt-2 flex justify-end">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowFileUpload(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        ) : selectedFile && (
          <div className="mb-4 flex items-center gap-2 p-2 bg-muted rounded-md">
            <div className="flex-1 truncate text-sm">
              File attached: {selectedFile.name}
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleClearFile}
              className="h-6 w-6 p-0 rounded-full"
            >
              <span className="sr-only">Remove file</span>
              <span aria-hidden="true">×</span>
            </Button>
          </div>
        )}
        
        <div className="flex items-end">
          <Textarea
            ref={textareaRef}
            value={message}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            placeholder="Send a message or share knowledge..."
            className="pr-12 resize-none min-h-[50px] max-h-[200px] py-3"
            disabled={isLoading}
          />
          <div className="absolute right-2 bottom-2 flex">
            {!selectedFile && (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="rounded-full mr-1"
                onClick={() => setShowFileUpload(true)}
                title="Attach a file to teach the AI"
              >
                <span className="sr-only">Attach file</span>
                <FileUp className="h-4 w-4" />
              </Button>
            )}
            <Button
              size="icon"
              className="rounded-full"
              onClick={handleSubmit}
              disabled={(!message.trim() && !selectedFile) || isLoading}
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
      <div className="text-center mt-2 text-xs text-muted-foreground">
        This is a learning AI assistant that learns from your input and files.
      </div>
    </div>
  );
};

export default ChatInput;
