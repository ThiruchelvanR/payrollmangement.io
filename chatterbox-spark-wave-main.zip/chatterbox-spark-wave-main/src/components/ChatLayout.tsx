
import React from "react";
import ChatHeader from "./ChatHeader";
import ChatMessages from "./ChatMessages";
import ChatInput from "./ChatInput";
import ChatSidebar from "./ChatSidebar";
import { SidebarProvider, Sidebar, SidebarContent, SidebarHeader, SidebarInset } from "./ui/sidebar";
import { Button } from "./ui/button";
import { PanelLeftIcon } from "lucide-react";

const ChatLayout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = React.useState(true);
  
  return (
    <SidebarProvider defaultOpen={true}>
      <div className="flex h-screen bg-secondary/30">
        <Sidebar>
          <SidebarHeader>
            <div className="p-2 flex items-center justify-between">
              <div className="font-medium">Chat History</div>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <ChatSidebar />
          </SidebarContent>
        </Sidebar>
        
        <SidebarInset>
          <div className="flex flex-col h-full">
            <ChatHeader />
            <ChatMessages />
            <ChatInput />
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
};

export default ChatLayout;
