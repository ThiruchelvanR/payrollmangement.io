
import React, { useEffect, useRef } from "react";
import { useChat } from "@/contexts/ChatContext";
import MessageBubble from "./MessageBubble";
import LoadingDots from "./LoadingDots";
import RobotAnimation from "./RobotAnimation";

const ChatMessages: React.FC = () => {
  const { messages, isLoading, showWelcomeMessage, setShowWelcomeMessage } = useChat();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Hide welcome message if there are messages
  useEffect(() => {
    if (messages.length > 0 && showWelcomeMessage) {
      setShowWelcomeMessage(false);
    }
  }, [messages, showWelcomeMessage, setShowWelcomeMessage]);

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide p-4 md:p-6">
      {showWelcomeMessage && messages.length === 0 ? (
        <div className="h-full flex flex-col items-center justify-center">
          <RobotAnimation 
            size="lg"
            robotName="JI Assistant"
            assistantName="PAYROLL CHAT ASSISTANT"
            welcomeMessage="Hello! I'm your AI assistant"
          />
          <p className="text-lg text-center mt-6 max-w-md text-muted-foreground animate-fade-in">
            I'm your Payroll Assistant. Ask me anything about payroll, and I'll do my best to help you!
          </p>
        </div>
      ) : (
        <div className="max-w-4xl mx-auto">
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))}

          {isLoading && (
            <div className="flex items-start gap-3 py-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                <LoadingDots className="text-primary" />
              </div>
              <div className="px-4 py-3 rounded-2xl bg-chatbot-assistant border border-chatbot-assistantBorder text-foreground rounded-tl-none max-w-[80%]">
                <span className="text-muted-foreground">Thinking...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      )}
    </div>
  );
};

export default ChatMessages;
