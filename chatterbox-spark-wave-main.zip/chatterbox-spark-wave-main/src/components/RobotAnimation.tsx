
import React, { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { Bot, MessageCircle, Sparkles } from "lucide-react";

interface RobotAnimationProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  robotName?: string;
  assistantName?: string;
  welcomeMessage?: string;
}

const RobotAnimation: React.FC<RobotAnimationProps> = ({
  className,
  size = "md",
  robotName = "JI Assistant",
  assistantName = "PAYROLL CHAT ASSISTANT",
  welcomeMessage = "Hello! Ready to chat?"
}) => {
  const sizeClasses = {
    sm: "w-20 h-20",
    md: "w-32 h-32",
    lg: "w-48 h-48",
  };

  const [animationState, setAnimationState] = useState(0);
  
  // Cycle through animation states
  useEffect(() => {
    const interval = setInterval(() => {
      setAnimationState((prev) => (prev + 1) % 3);
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={cn("flex flex-col items-center", className)}>
      <div className={cn("relative flex items-center justify-center", sizeClasses[size])}>
        {/* Robot avatar with layered animation */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/20 via-primary/10 to-primary/30 animate-pulse"></div>
        <div className="absolute rounded-full w-3/4 h-3/4 bg-gradient-to-r from-purple-500 to-blue-500 opacity-30 animate-ping"></div>
        
        {/* Main robot avatar */}
        <div className="relative flex items-center justify-center w-full h-full">
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-400 via-indigo-500 to-purple-500 blur-sm animate-pulse"></div>
          <div className="relative z-10 rounded-full bg-white w-[90%] h-[90%] flex items-center justify-center shadow-lg">
            {animationState === 0 && (
              <Bot size={sizeClasses[size] === "w-20 h-20" ? 32 : sizeClasses[size] === "w-32 h-32" ? 48 : 64} 
                  className="text-primary animate-bounce-in" />
            )}
            {animationState === 1 && (
              <MessageCircle size={sizeClasses[size] === "w-20 h-20" ? 32 : sizeClasses[size] === "w-32 h-32" ? 48 : 64}
                      className="text-indigo-500 animate-bounce-in" />
            )}
            {animationState === 2 && (
              <Sparkles size={sizeClasses[size] === "w-20 h-20" ? 32 : sizeClasses[size] === "w-32 h-32" ? 48 : 64}
                     className="text-purple-500 animate-bounce-in" />
            )}
          </div>
        </div>
        
        {/* Floating particles around robot */}
        <div className="absolute -top-2 -right-1 w-4 h-4 rounded-full bg-blue-400 animate-float opacity-70"></div>
        <div className="absolute top-1/4 -left-2 w-3 h-3 rounded-full bg-purple-400 animate-float opacity-70" style={{ animationDelay: "1s" }}></div>
        <div className="absolute bottom-0 right-1/4 w-2 h-2 rounded-full bg-indigo-400 animate-float opacity-70" style={{ animationDelay: "1.5s" }}></div>
      </div>
      
      {/* Welcome message with animated gradient text */}
      <div className="mt-6 text-lg font-medium animate-fade-in text-center">
        <span className="inline-block bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-transparent bg-clip-text animate-pulse">
          {welcomeMessage}
        </span>
      </div>
      
      {/* Assistant name with subtle animation */}
      <div className="mt-2 text-xs font-semibold tracking-wider text-center">
        <span className="inline-block text-muted-foreground animate-fade-in" style={{ animationDelay: "0.5s" }}>
          {assistantName}
        </span>
      </div>
    </div>
  );
};

export default RobotAnimation;
