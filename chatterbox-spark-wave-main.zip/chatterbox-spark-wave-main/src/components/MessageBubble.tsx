
import React from "react";
import { cn } from "@/lib/utils";
import { Message } from "@/contexts/ChatContext";
import TypewriterText from "./TypewriterText";
import MessageActions from "./MessageActions";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const { user } = useAuth();
  const isUser = message.type === "user";
  
  // Format time like "10:30 AM"
  const formattedTime = message.timestamp.toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit",
  });

  return (
    <div
      className={cn(
        "flex w-full gap-3 py-4 group",
        isUser ? "justify-end" : "justify-start"
      )}
    >
      {!isUser && (
        <Avatar className="h-8 w-8">
          <AvatarImage src="/robot-avatar.png" alt="JI Assistant" />
          <AvatarFallback className="bg-primary text-primary-foreground">JI</AvatarFallback>
        </Avatar>
      )}

      <div className={cn("flex flex-col max-w-[80%] md:max-w-[70%]", isUser ? "items-end" : "items-start")}>
        <div
          className={cn(
            "px-4 py-3 rounded-2xl mb-1",
            isUser
              ? "bg-primary text-primary-foreground rounded-tr-none"
              : "bg-chatbot-assistant border border-chatbot-assistantBorder text-foreground rounded-tl-none"
          )}
        >
          {isUser || !message.isAnimating ? (
            <div className="whitespace-pre-wrap">{message.content}</div>
          ) : (
            <TypewriterText text={message.content} />
          )}
        </div>
        
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">{formattedTime}</span>
          <MessageActions message={message} />
        </div>
      </div>
      
      {isUser && (
        <Avatar className="h-8 w-8">
          <AvatarImage src={user?.avatar} alt={user?.name} />
          <AvatarFallback className="bg-primary text-primary-foreground">
            {user?.name?.charAt(0) || "U"}
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  );
};

export default MessageBubble;
