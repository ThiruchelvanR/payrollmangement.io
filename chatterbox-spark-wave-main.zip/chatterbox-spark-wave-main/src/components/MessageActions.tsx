
import React from "react";
import { 
  Copy, 
  Share2, 
  RefreshCw, 
  ThumbsUp, 
  ThumbsDown 
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Message, useChat } from "@/contexts/ChatContext";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface MessageActionsProps {
  message: Message;
}

const MessageActions: React.FC<MessageActionsProps> = ({ message }) => {
  const { retryMessage, giveFeedback } = useChat();

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    toast({
      title: "Copied to clipboard",
      description: "Message content has been copied to your clipboard",
    });
  };

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(`${message.content}\n\nShared from: ${url}`);
    toast({
      title: "Ready to share",
      description: "Message and link copied to clipboard",
    });
  };

  const handleRetry = () => {
    retryMessage(message.id);
  };

  const handleFeedback = (type: "positive" | "negative") => {
    giveFeedback(message.id, type);
  };

  return (
    <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleCopy}>
              <Copy className="h-4 w-4" />
              <span className="sr-only">Copy message</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Copy to clipboard</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleShare}>
              <Share2 className="h-4 w-4" />
              <span className="sr-only">Share message</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Share message</p>
          </TooltipContent>
        </Tooltip>

        {message.type === "user" && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleRetry}>
                <RefreshCw className="h-4 w-4" />
                <span className="sr-only">Retry message</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Retry this message</p>
            </TooltipContent>
          </Tooltip>
        )}

        {message.type === "assistant" && message.hasFeedback && (
          <>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon" 
                  className={`h-8 w-8 ${message.feedback === "positive" ? "text-green-500" : ""}`}
                  onClick={() => handleFeedback("positive")}
                >
                  <ThumbsUp className="h-4 w-4" />
                  <span className="sr-only">Mark as helpful</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Mark as helpful</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon" 
                  className={`h-8 w-8 ${message.feedback === "negative" ? "text-red-500" : ""}`}
                  onClick={() => handleFeedback("negative")}
                >
                  <ThumbsDown className="h-4 w-4" />
                  <span className="sr-only">Mark as not helpful</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Mark as not helpful</p>
              </TooltipContent>
            </Tooltip>
          </>
        )}
      </TooltipProvider>
    </div>
  );
};

export default MessageActions;
