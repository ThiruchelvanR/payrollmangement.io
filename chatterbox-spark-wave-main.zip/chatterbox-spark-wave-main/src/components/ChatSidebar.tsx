
import React from "react";
import { useChat } from "@/contexts/ChatContext";
import { useAuth } from "@/contexts/AuthContext";
import { formatDistanceToNow } from "date-fns";
import { PlusCircle, Trash2 } from "lucide-react";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";

const ChatSidebar: React.FC = () => {
  const { 
    chatSessions, 
    createNewChat, 
    loadChatSession, 
    deleteChatSession, 
    currentSession,
    isLoadingSessions
  } = useChat();
  
  const { user } = useAuth();

  if (!user) {
    return null;
  }

  return (
    <div className="w-64 border-r border-border bg-muted/40 h-full flex flex-col">
      <div className="p-4 border-b flex-shrink-0">
        <Button 
          variant="outline" 
          className="w-full flex items-center justify-start gap-2" 
          onClick={createNewChat}>
          <PlusCircle size={16} />
          New Chat
        </Button>
      </div>
      
      <ScrollArea className="flex-grow">
        <div className="p-2 space-y-1">
          {isLoadingSessions ? (
            <div className="flex items-center justify-center p-4">
              <div className="animate-pulse space-y-2 w-full">
                <div className="h-10 bg-muted-foreground/10 rounded-md w-full" />
                <div className="h-10 bg-muted-foreground/10 rounded-md w-full" />
                <div className="h-10 bg-muted-foreground/10 rounded-md w-full" />
              </div>
            </div>
          ) : chatSessions.length === 0 ? (
            <div className="text-center py-4 text-muted-foreground text-sm">
              No chat history
            </div>
          ) : (
            chatSessions.map((session) => (
              <div 
                key={session.id} 
                className={`group flex items-center justify-between p-2 rounded-md cursor-pointer hover:bg-accent hover:text-accent-foreground transition-colors text-sm ${
                  currentSession?.id === session.id ? 'bg-accent text-accent-foreground' : ''
                }`}
                onClick={() => loadChatSession(session.id)}
              >
                <div className="truncate flex-1">
                  <div className="font-medium truncate">{session.title}</div>
                  <div className="text-xs text-muted-foreground">
                    {formatDistanceToNow(session.updatedAt, { addSuffix: true })}
                  </div>
                </div>
                
                <Button
                  variant="ghost"
                  size="icon"
                  className="opacity-0 group-hover:opacity-100 transition-opacity h-7 w-7"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteChatSession(session.id);
                  }}
                >
                  <Trash2 size={14} />
                </Button>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default ChatSidebar;
