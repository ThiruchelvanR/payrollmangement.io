
import React from "react";
import { cn } from "@/lib/utils";

interface LoadingDotsProps {
  className?: string;
}

const LoadingDots: React.FC<LoadingDotsProps> = ({ className }) => {
  return (
    <div className={cn("flex items-center space-x-1", className)}>
      <div className="w-2 h-2 rounded-full bg-current animate-loader-dot1" />
      <div className="w-2 h-2 rounded-full bg-current animate-loader-dot2" />
      <div className="w-2 h-2 rounded-full bg-current animate-loader-dot3" />
    </div>
  );
};

export default LoadingDots;
