
import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { toast } from "@/hooks/use-toast";
import { v4 as uuidv4 } from "uuid";

export type MessageType = "user" | "assistant";

export interface Message {
  id: string;
  content: string;
  type: MessageType;
  timestamp: Date;
  isAnimating?: boolean;
  hasFeedback?: boolean;
  feedback?: "positive" | "negative" | null;
  attachment?: {
    name: string;
    type: string;
    url?: string;
  } | null;
}

interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
}

interface ChatContextType {
  messages: Message[];
  isLoading: boolean;
  currentSession: ChatSession | null;
  chatSessions: ChatSession[];
  sendMessage: (content: string, attachment?: File | null) => Promise<void>;
  retryMessage: (messageId: string) => Promise<void>;
  giveFeedback: (messageId: string, feedback: "positive" | "negative") => void;
  clearMessages: () => void;
  showWelcomeMessage: boolean;
  setShowWelcomeMessage: (show: boolean) => void;
  createNewChat: () => Promise<void>;
  loadChatSession: (sessionId: string) => Promise<void>;
  deleteChatSession: (sessionId: string) => Promise<void>;
  isLoadingSessions: boolean;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

// Knowledge base for learning
const initialKnowledgeBase = [
  "I can help answer questions about programming languages like JavaScript, TypeScript, Python, and more.",
  "React is a JavaScript library for building user interfaces, particularly single-page applications.",
  "TypeScript is a strongly typed programming language that builds on JavaScript.",
  "Tailwind CSS is a utility-first CSS framework for rapidly building custom user interfaces.",
  "Node.js is a JavaScript runtime built on Chrome's V8 JavaScript engine.",
  "API stands for Application Programming Interface and allows different software applications to communicate with each other."
];

// Function to save data to localStorage
const saveToLocalStorage = (key: string, data: any) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving to localStorage (${key}):`, error);
  }
};

// Function to load data from localStorage
const loadFromLocalStorage = (key: string, defaultValue: any = null) => {
  try {
    const savedData = localStorage.getItem(key);
    return savedData ? JSON.parse(savedData) : defaultValue;
  } catch (error) {
    console.error(`Error loading from localStorage (${key}):`, error);
    return defaultValue;
  }
};

export const ChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingSessions, setIsLoadingSessions] = useState(false);
  const [showWelcomeMessage, setShowWelcomeMessage] = useState(true);
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null);
  const [knowledgeBase, setKnowledgeBase] = useState<string[]>(initialKnowledgeBase);

  // Load sessions from localStorage
  useEffect(() => {
    const fetchChatSessions = async () => {
      try {
        setIsLoadingSessions(true);
        const savedSessions = loadFromLocalStorage('chatSessions', []);
        
        // Format dates which were serialized as strings back to Date objects
        const formattedSessions = savedSessions.map((session: any) => ({
          ...session,
          createdAt: new Date(session.createdAt),
          updatedAt: new Date(session.updatedAt),
          messages: session.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          }))
        }));
        
        setChatSessions(formattedSessions);

        // Load current session if exists
        const savedCurrentSessionId = localStorage.getItem('currentSessionId');
        if (savedCurrentSessionId) {
          const currentSession = formattedSessions.find((s: ChatSession) => s.id === savedCurrentSessionId);
          if (currentSession) {
            setCurrentSession(currentSession);
            setMessages(currentSession.messages);
          }
        }
      } catch (error) {
        console.error("Error fetching chat sessions:", error);
        toast({
          variant: "destructive",
          title: "Error loading sessions",
          description: "Failed to load your previous conversations.",
        });
      } finally {
        setIsLoadingSessions(false);
      }
    };

    fetchChatSessions();
    
    // Load knowledge base from localStorage if exists
    const savedKnowledge = loadFromLocalStorage('knowledgeBase', null);
    if (savedKnowledge) {
      setKnowledgeBase(savedKnowledge);
    }
  }, []);

  // Save sessions to localStorage when they change
  useEffect(() => {
    if (chatSessions.length > 0) {
      saveToLocalStorage('chatSessions', chatSessions);
    }
  }, [chatSessions]);

  // Save current session ID to localStorage when it changes
  useEffect(() => {
    if (currentSession) {
      localStorage.setItem('currentSessionId', currentSession.id);
    }
  }, [currentSession?.id]);

  // Save knowledge base to localStorage when it changes
  useEffect(() => {
    saveToLocalStorage('knowledgeBase', knowledgeBase);
  }, [knowledgeBase]);

  const createNewChat = async (): Promise<void> => {
    try {
      const newSessionId = uuidv4();
      const newSession: ChatSession = {
        id: newSessionId,
        title: "New Conversation",
        messages: [],
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // Add to session list
      setChatSessions(prev => [newSession, ...prev]);
      
      // Set as current session
      setCurrentSession(newSession);
      setMessages([]);
      
      toast({
        title: "New chat created",
        description: "You can now start a new conversation.",
      });
    } catch (error) {
      console.error("Error creating new chat:", error);
      toast({
        variant: "destructive",
        title: "Error creating new chat",
        description: "Failed to create a new chat. Please try again.",
      });
    }
  };

  const loadChatSession = async (sessionId: string) => {
    try {
      const session = chatSessions.find(s => s.id === sessionId);
      if (session) {
        setCurrentSession(session);
        setMessages(session.messages);
      } else {
        toast({
          variant: "destructive",
          title: "Session not found",
          description: "The requested chat session couldn't be found.",
        });
      }
    } catch (error) {
      console.error("Error loading chat session:", error);
      toast({
        variant: "destructive",
        title: "Error loading chat",
        description: "Failed to load the selected chat. Please try again.",
      });
    }
  };

  const deleteChatSession = async (sessionId: string) => {
    try {
      // Remove from local state
      setChatSessions(prev => prev.filter(s => s.id !== sessionId));
      
      // If current session was deleted, create a new one
      if (currentSession?.id === sessionId) {
        // We need to create a new chat but shouldn't test the return value
        await createNewChat();
      }
      
      toast({
        title: "Chat deleted",
        description: "The chat has been successfully deleted.",
      });
    } catch (error) {
      console.error("Error deleting chat session:", error);
      toast({
        variant: "destructive",
        title: "Error deleting chat",
        description: "Failed to delete the chat. Please try again.",
      });
    }
  };

  // Function to generate response based on knowledge base and message content
  const generateAIResponse = async (userMessage: string) => {
    // Simple keyword-based response for demo purposes
    // In a real application, this would connect to an external API or ML model

    // Learn from user input by adding it to knowledge base if it appears to be factual
    // This is a very simple implementation - in a real app you'd use ML to determine this
    if (userMessage.includes("is") && userMessage.length > 20 && !userMessage.includes("?")) {
      // Simple heuristic to identify potential factual statements
      const newKnowledge = userMessage.trim();
      setKnowledgeBase(prev => [...prev, newKnowledge]);
    }
    
    // Check knowledge base for relevant information
    const relevantKnowledge = knowledgeBase.filter(item => 
      userMessage.toLowerCase().split(" ").some(word => 
        word.length > 3 && item.toLowerCase().includes(word.toLowerCase())
      )
    );
    
    // Simulate fetching from external sources
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Programming language detection
    const programmingLanguages = [
      "JavaScript", "TypeScript", "Python", "Java", "C#", "C++", 
      "PHP", "Ruby", "Swift", "Kotlin", "Go", "Rust"
    ];
    
    const detectedLanguages = programmingLanguages.filter(lang => 
      userMessage.toLowerCase().includes(lang.toLowerCase())
    );
    
    if (detectedLanguages.length > 0) {
      return `I see you're asking about ${detectedLanguages.join(", ")}. Let me provide some information based on my knowledge.${
        relevantKnowledge.length > 0 ? "\n\n" + relevantKnowledge.join("\n\n") : 
        "\n\nI'm continuously learning about programming languages. Please share any specific questions about syntax, best practices, or frameworks."
      }`;
    }
    
    if (relevantKnowledge.length > 0) {
      return `Based on what I've learned: \n\n${relevantKnowledge.join("\n\n")}`;
    }
    
    return "I'm still learning about this topic. Could you share more information that might help me understand better?";
  };

  const sendMessage = async (content: string, attachment: File | null = null) => {
    if (!content.trim() && !attachment) return;

    try {
      // If no current session, create one
      if (!currentSession) {
        // Don't test the return value of createNewChat
        await createNewChat();
      }
      
      // Create attachment metadata if there's a file
      const attachmentMeta = attachment ? {
        name: attachment.name,
        type: attachment.type,
        url: URL.createObjectURL(attachment)
      } : null;

      const userMessageId = uuidv4();
      
      // Add user message
      const userMessage: Message = {
        id: userMessageId,
        content,
        type: "user",
        timestamp: new Date(),
        attachment: attachmentMeta
      };

      // Save to state for immediate display
      setMessages(prev => [...prev, userMessage]);
      
      // Update session with this message
      const updatedSession = {
        ...currentSession!,
        messages: [...currentSession!.messages, userMessage],
        updatedAt: new Date(),
        title: currentSession!.messages.length === 0 ? 
          (content.length > 30 ? content.substring(0, 30) + "..." : content) : 
          currentSession!.title
      };
      
      setCurrentSession(updatedSession);
      
      // Update chat sessions list
      setChatSessions(prev => prev.map(s => 
        s.id === updatedSession.id ? updatedSession : s
      ));

      setIsLoading(true);

      try {
        // Generate response
        const responseText = await generateAIResponse(content);
        
        // Create bot response
        const botResponseId = uuidv4();
        const botResponse: Message = {
          id: botResponseId,
          content: responseText,
          type: "assistant",
          timestamp: new Date(),
          isAnimating: true,
          hasFeedback: true,
        };

        setMessages(prev => [...prev, botResponse]);

        // Update session with bot response
        const sessionWithBotResponse = {
          ...updatedSession,
          messages: [...updatedSession.messages, botResponse],
          updatedAt: new Date()
        };
        
        setCurrentSession(sessionWithBotResponse);
        
        // Update chat sessions list
        setChatSessions(prev => prev.map(s => 
          s.id === sessionWithBotResponse.id ? sessionWithBotResponse : s
        ));

        // After animation completes, mark it as no longer animating
        setTimeout(() => {
          setMessages(prev =>
            prev.map(msg =>
              msg.id === botResponse.id ? { ...msg, isAnimating: false } : msg
            )
          );
          
          // Update in sessions state too
          setChatSessions(prev => prev.map(session => {
            if (session.id !== currentSession?.id) return session;
            
            return {
              ...session,
              messages: session.messages.map(msg => 
                msg.id === botResponse.id ? { ...msg, isAnimating: false } : msg
              )
            };
          }));
        }, 1500);
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error sending message",
          description: "Failed to get a response. Please try again.",
        });
      } finally {
        setIsLoading(false);
      }
    } catch (error) {
      console.error("Error in send message flow:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Something went wrong. Please try again.",
      });
      setIsLoading(false);
    }
  };

  const retryMessage = async (messageId: string) => {
    // Find the user message to retry
    const userMessage = messages.find(m => m.id === messageId);
    if (!userMessage || userMessage.type !== "user") return;

    // Remove all messages after this one
    const messageIndex = messages.findIndex(m => m.id === messageId);
    const newMessages = messages.slice(0, messageIndex + 1);
    setMessages(newMessages);

    // Update session
    if (currentSession) {
      const updatedSession = {
        ...currentSession,
        messages: newMessages,
        updatedAt: new Date()
      };
      
      setCurrentSession(updatedSession);
      
      // Update chat sessions list
      setChatSessions(prev => prev.map(s => 
        s.id === updatedSession.id ? updatedSession : s
      ));
    }

    // Re-send the message
    await sendMessage(userMessage.content, null);
  };

  const giveFeedback = (messageId: string, feedback: "positive" | "negative") => {
    // Update the message with feedback
    const updatedMessages = messages.map(msg =>
      msg.id === messageId ? { ...msg, feedback } : msg
    );
    
    setMessages(updatedMessages);
    
    // Update in session too
    if (currentSession) {
      const updatedSession = {
        ...currentSession,
        messages: updatedMessages
      };
      
      setCurrentSession(updatedSession);
      
      // Update chat sessions list
      setChatSessions(prev => prev.map(s => 
        s.id === updatedSession.id ? updatedSession : s
      ));
    }

    // If positive feedback on an assistant message, add it to knowledge base
    const message = messages.find(m => m.id === messageId);
    if (feedback === "positive" && message?.type === "assistant") {
      // In a real app, you'd analyze the content before adding to knowledge base
      const newKnowledge = message.content
        .split("\n\n")
        .filter(line => line.length > 20)
        .slice(0, 2); // Take first two paragraphs at most
      
      if (newKnowledge.length > 0) {
        setKnowledgeBase(prev => [...prev, ...newKnowledge]);
      }
    }

    toast({
      title: feedback === "positive" ? "Thank you for your feedback!" : "Sorry to hear that",
      description: feedback === "positive" ? "We're glad this was helpful." : "We'll work on improving our responses.",
    });
  };

  const clearMessages = () => {
    setMessages([]);
    
    // Create a new session
    createNewChat();
    
    toast({
      title: "Chat cleared",
      description: "All messages have been removed.",
    });
  };

  return (
    <ChatContext.Provider value={{
      messages,
      isLoading,
      currentSession,
      chatSessions,
      sendMessage,
      retryMessage,
      giveFeedback,
      clearMessages,
      showWelcomeMessage,
      setShowWelcomeMessage,
      createNewChat,
      loadChatSession,
      deleteChatSession,
      isLoadingSessions
    }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error("useChat must be used within a ChatProvider");
  }
  return context;
};
